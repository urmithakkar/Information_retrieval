const ratingsEl = document.querySelectorAll(".rating");
const sendBtn = document.querySelector("#send");
const panel = document.querySelector("#panel");

ratingsEl.forEach((el) => {
    el.addEventListener("click", () => {
        ratingsEl.forEach((innerEl) => {
            innerEl.classList.remove("active");
        });

        el.classList.add("active");
    });
});
sendBtn.addEventListener("click", async(ev) => {
    ev.preventDefault();
    var rating = document.getElementById("answer1").innerText;
    var input = document.getElementById("user_input").value;

    console.log("Rating=" + rating);
    console.log("User Input=" + input);
})

sendBtn.addEventListener("click", () => {
    panel.innerHTML = `
		<i class="fas fa-heart"></i>
		<strong>Thank you!</strong>
		<p>We'll use your feedback to improve.</p>
		<button class="btn" onclick="location.href='Search.html'">Done</button>
	`;
});